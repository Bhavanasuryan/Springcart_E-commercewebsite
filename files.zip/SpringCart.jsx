import { useState, useEffect, useCallback } from "react";

const PRODUCTS = [
  { id:1,  name:"iPhone 15 Pro Max",        price:134900, originalPrice:139900, category:"Electronics", brand:"Apple",       rating:4.8, reviews:1243, stock:50,  image:"https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&auto=format&fit=crop", description:"Apple's flagship with A17 Pro chip, 48MP camera system, and titanium design. 5G ready, USB-C.", badge:"Best Seller" },
  { id:2,  name:"Samsung Galaxy S24 Ultra",  price:124999, originalPrice:129999, category:"Electronics", brand:"Samsung",    rating:4.7, reviews:987,  stock:45,  image:"https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=600&auto=format&fit=crop", description:"Ultimate Android flagship with 200MP camera, built-in S Pen, Snapdragon 8 Gen 3.", badge:"New" },
  { id:3,  name:"Sony WH-1000XM5",           price:29990,  originalPrice:34990,  category:"Electronics", brand:"Sony",       rating:4.9, reviews:3201, stock:120, image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop", description:"Industry-leading noise cancelling headphones, 30-hour battery, Speak-to-Chat.", badge:"Top Rated" },
  { id:4,  name:'MacBook Pro 14" M3',        price:199900, originalPrice:209900, category:"Electronics", brand:"Apple",       rating:4.9, reviews:567,  stock:30,  image:"https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&auto=format&fit=crop", description:"M3 chip, 18-hour battery, Liquid Retina XDR display, pro-level performance.", badge:"" },
  { id:5,  name:'iPad Pro 12.9"',            price:112900, originalPrice:119900, category:"Electronics", brand:"Apple",       rating:4.7, reviews:432,  stock:40,  image:"https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=600&auto=format&fit=crop", description:"M2 chip, Liquid Retina XDR display, Wi-Fi 6E, USB 4 connectivity.", badge:"" },
  { id:6,  name:"Dell XPS 15",               price:189990, originalPrice:199990, category:"Electronics", brand:"Dell",        rating:4.6, reviews:289,  stock:25,  image:"https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=600&auto=format&fit=crop", description:"15.6 OLED, Intel Core i9, NVIDIA RTX 4060, 32GB RAM. The premium Windows laptop.", badge:"" },
  { id:7,  name:"Levi's 501 Original Jeans", price:5999,   originalPrice:6999,   category:"Fashion",     brand:"Levi's",      rating:4.5, reviews:8923, stock:200, image:"https://images.unsplash.com/photo-1542272454315-4c01d7abdf4a?w=600&auto=format&fit=crop", description:"Original straight-leg jeans, button fly. Iconic since 1873, sustainable cotton.", badge:"Classic" },
  { id:8,  name:"Nike Air Max 270",           price:13995,  originalPrice:15995,  category:"Fashion",     brand:"Nike",        rating:4.6, reviews:5678, stock:85,  image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop", description:"Largest Air unit yet for incredible underfoot cushioning. Lightweight mesh upper.", badge:"" },
  { id:9,  name:"Adidas Ultraboost 22",       price:17999,  originalPrice:19999,  category:"Fashion",     brand:"Adidas",      rating:4.7, reviews:3421, stock:60,  image:"https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=600&auto=format&fit=crop", description:"Energy-returning Boost midsole with Primeknit+ upper. Loved by runners worldwide.", badge:"" },
  { id:10, name:"Zara Linen Blend Blazer",   price:4990,   originalPrice:5990,   category:"Fashion",     brand:"Zara",        rating:4.3, reviews:1234, stock:150, image:"https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&auto=format&fit=crop", description:"Relaxed-fit blazer in linen blend. Notch lapels, padded shoulders, welt pockets.", badge:"Trending" },
  { id:11, name:"Instant Pot Duo 7-in-1",    price:8999,   originalPrice:10999,  category:"Home & Kitchen", brand:"Instant Pot", rating:4.7, reviews:12034,stock:180, image:"https://images.unsplash.com/photo-1585515320310-259814833e62?w=600&auto=format&fit=crop", description:"Pressure cooker, slow cooker, rice cooker, steamer, saute, yogurt maker in one.", badge:"Best Seller" },
  { id:12, name:"Dyson V15 Detect",          price:54900,  originalPrice:59900,  category:"Home & Kitchen", brand:"Dyson",       rating:4.8, reviews:2341, stock:35,  image:"https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&auto=format&fit=crop", description:"Laser reveals invisible dust. 60 min run time, HEPA filtration, intelligent sensor.", badge:"" },
  { id:13, name:"Breville Barista Express",  price:64900,  originalPrice:69900,  category:"Home & Kitchen", brand:"Breville",    rating:4.9, reviews:4567, stock:20,  image:"https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&auto=format&fit=crop", description:"Built-in conical burr grinder delivers the perfect dose directly into the portafilter.", badge:"Top Rated" },
  { id:14, name:"Yonex VCORE 100 Racket",   price:12999,  originalPrice:14999,  category:"Sports",       brand:"Yonex",       rating:4.6, reviews:876,  stock:55,  image:"https://images.unsplash.com/photo-1551773188-0801da12ddae?w=600&auto=format&fit=crop", description:"Power meets control. Graphite frame with VDM. 300g, perfect for aggressive baseline play.", badge:"" },
  { id:15, name:"Fitbit Charge 6",           price:14999,  originalPrice:16999,  category:"Sports",       brand:"Fitbit",      rating:4.4, reviews:3456, stock:90,  image:"https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=600&auto=format&fit=crop", description:"Advanced fitness tracker with GPS, ECG app, Google Maps and Wallet integration.", badge:"" },
  { id:16, name:"Atomic Habits",             price:499,    originalPrice:599,    category:"Books",        brand:"Avery",       rating:4.9, reviews:54321,stock:500, image:"https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&auto=format&fit=crop", description:"James Clear's #1 NYT Bestseller. Build good habits, break bad ones with science.", badge:"#1 Bestseller" },
  { id:17, name:"Clean Code",                price:699,    originalPrice:799,    category:"Books",        brand:"Prentice Hall",rating:4.7,reviews:23456,stock:300, image:"https://images.unsplash.com/photo-1507721999472-8ed4421c4af2?w=600&auto=format&fit=crop", description:"Robert C. Martin's handbook of agile software craftsmanship. Essential for developers.", badge:"" },
];

const CATEGORIES = ["All","Electronics","Fashion","Home & Kitchen","Sports","Books"];
const fmt = n => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n);
const Stars = ({r}) => <span style={{color:"#f59e0b",fontSize:13}}>{"★".repeat(Math.floor(r))}{"☆".repeat(5-Math.floor(r))}</span>;

const Toast = ({msg,onClose}) => {
  useEffect(()=>{const t=setTimeout(onClose,2500);return()=>clearTimeout(t);},[onClose]);
  return <div style={{position:"fixed",bottom:28,right:28,zIndex:9999,background:"#0f172a",color:"#fff",padding:"12px 20px",borderRadius:12,fontSize:14,fontWeight:500,boxShadow:"0 8px 32px rgba(0,0,0,0.3)",display:"flex",alignItems:"center",gap:10,animation:"slideUp .3s ease"}}><span style={{color:"#34d399",fontSize:18}}>✓</span>{msg}</div>;
};

const badgeColor = b => b==="Best Seller"?"#f59e0b":b==="Top Rated"?"#10b981":b==="New"?"#3b82f6":"#8b5cf6";

const ProductCard = ({product,onAddToCart,onView}) => {
  const [hov,setHov]=useState(false);
  const disc=Math.round((1-product.price/product.originalPrice)*100);
  return (
    <div onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)} style={{background:"#fff",borderRadius:16,overflow:"hidden",boxShadow:hov?"0 20px 60px rgba(0,0,0,.12)":"0 2px 12px rgba(0,0,0,.06)",transition:"all .3s",transform:hov?"translateY(-4px)":"none",cursor:"pointer",border:"1px solid #f1f5f9",display:"flex",flexDirection:"column"}}>
      <div style={{position:"relative",overflow:"hidden",height:220}} onClick={()=>onView(product)}>
        <img src={product.image} alt={product.name} style={{width:"100%",height:"100%",objectFit:"cover",transition:"transform .4s",transform:hov?"scale(1.06)":"scale(1)"}}/>
        {product.badge&&<span style={{position:"absolute",top:12,left:12,background:badgeColor(product.badge),color:"#fff",padding:"3px 10px",borderRadius:20,fontSize:11,fontWeight:700}}>{product.badge}</span>}
        {disc>0&&<span style={{position:"absolute",top:12,right:12,background:"#ef4444",color:"#fff",padding:"3px 8px",borderRadius:20,fontSize:11,fontWeight:700}}>{disc}% OFF</span>}
      </div>
      <div style={{padding:"16px 16px 12px",flex:1,display:"flex",flexDirection:"column"}}>
        <div style={{fontSize:11,color:"#94a3b8",fontWeight:600,letterSpacing:"0.5px",marginBottom:4,textTransform:"uppercase"}}>{product.brand}</div>
        <div style={{fontWeight:700,fontSize:15,color:"#0f172a",lineHeight:1.3,marginBottom:8,flex:1}} onClick={()=>onView(product)}>{product.name}</div>
        <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:10}}><Stars r={product.rating}/><span style={{fontSize:12,color:"#94a3b8"}}>({product.reviews.toLocaleString()})</span></div>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}>
          <span style={{fontSize:18,fontWeight:800,color:"#0f172a"}}>{fmt(product.price)}</span>
          {disc>0&&<span style={{fontSize:13,color:"#94a3b8",textDecoration:"line-through"}}>{fmt(product.originalPrice)}</span>}
        </div>
        <button onClick={e=>{e.stopPropagation();onAddToCart(product);}} style={{width:"100%",padding:"10px 0",background:"#0f172a",color:"#fff",border:"none",borderRadius:10,fontWeight:700,fontSize:13,cursor:"pointer"}}
          onMouseEnter={e=>e.target.style.background="#1e3a5f"} onMouseLeave={e=>e.target.style.background="#0f172a"}>
          Add to Cart
        </button>
      </div>
    </div>
  );
};

const ProductModal = ({product,onClose,onAddToCart}) => {
  const [qty,setQty]=useState(1);
  if(!product) return null;
  const disc=Math.round((1-product.price/product.originalPrice)*100);
  return (
    <div style={{position:"fixed",inset:0,zIndex:1000,background:"rgba(0,0,0,.5)",display:"flex",alignItems:"center",justifyContent:"center",padding:20}} onClick={onClose}>
      <div style={{background:"#fff",borderRadius:20,maxWidth:820,width:"100%",maxHeight:"90vh",overflow:"auto",display:"flex",flexWrap:"wrap"}} onClick={e=>e.stopPropagation()}>
        <div style={{width:"42%",minWidth:260,position:"relative"}}>
          <img src={product.image} alt={product.name} style={{width:"100%",height:"100%",minHeight:360,objectFit:"cover",borderRadius:"20px 0 0 20px"}}/>
          {disc>0&&<span style={{position:"absolute",top:16,right:16,background:"#ef4444",color:"#fff",padding:"4px 10px",borderRadius:20,fontSize:12,fontWeight:700}}>{disc}% OFF</span>}
        </div>
        <div style={{flex:1,padding:36,display:"flex",flexDirection:"column",gap:12,minWidth:280}}>
          <button onClick={onClose} style={{alignSelf:"flex-end",background:"#f1f5f9",border:"none",borderRadius:"50%",width:36,height:36,cursor:"pointer",fontSize:18}}>×</button>
          <div style={{fontSize:12,color:"#94a3b8",fontWeight:700,textTransform:"uppercase",letterSpacing:1}}>{product.brand} · {product.category}</div>
          <h2 style={{margin:0,fontSize:22,fontWeight:800,color:"#0f172a",lineHeight:1.3}}>{product.name}</h2>
          <div style={{display:"flex",alignItems:"center",gap:8}}><Stars r={product.rating}/><span style={{fontSize:13,color:"#64748b"}}>{product.rating} ({product.reviews.toLocaleString()} reviews)</span></div>
          <p style={{margin:0,color:"#475569",fontSize:14,lineHeight:1.7}}>{product.description}</p>
          <div style={{display:"flex",alignItems:"baseline",gap:10,marginTop:4}}>
            <span style={{fontSize:28,fontWeight:900,color:"#0f172a"}}>{fmt(product.price)}</span>
            {disc>0&&<><span style={{color:"#94a3b8",textDecoration:"line-through",fontSize:16}}>{fmt(product.originalPrice)}</span><span style={{color:"#10b981",fontWeight:700,fontSize:14}}>Save {fmt(product.originalPrice-product.price)}</span></>}
          </div>
          <div style={{color:product.stock>10?"#10b981":"#f59e0b",fontWeight:600,fontSize:13}}>{product.stock>10?"✓ In Stock":`⚠ Only ${product.stock} left`}</div>
          <div style={{display:"flex",alignItems:"center",gap:12,marginTop:8}}>
            <div style={{display:"flex",alignItems:"center",border:"2px solid #e2e8f0",borderRadius:10,overflow:"hidden"}}>
              <button onClick={()=>setQty(q=>Math.max(1,q-1))} style={{width:40,height:44,border:"none",background:"#f8fafc",fontSize:18,cursor:"pointer",fontWeight:700}}>−</button>
              <span style={{width:48,textAlign:"center",fontWeight:700,fontSize:16}}>{qty}</span>
              <button onClick={()=>setQty(q=>Math.min(product.stock,q+1))} style={{width:40,height:44,border:"none",background:"#f8fafc",fontSize:18,cursor:"pointer",fontWeight:700}}>+</button>
            </div>
            <button onClick={()=>{onAddToCart(product,qty);onClose();}} style={{flex:1,padding:"12px 0",background:"#0f172a",color:"#fff",border:"none",borderRadius:10,fontWeight:700,fontSize:15,cursor:"pointer"}}>Add {qty} to Cart</button>
          </div>
        </div>
      </div>
    </div>
  );
};

const CartSidebar = ({cart,onClose,onRemove,onUpdateQty,onCheckout}) => {
  const total=cart.reduce((s,i)=>s+i.price*i.qty,0);
  return (
    <div style={{position:"fixed",inset:0,zIndex:900,display:"flex"}}>
      <div style={{flex:1,background:"rgba(0,0,0,.4)"}} onClick={onClose}/>
      <div style={{width:420,maxWidth:"100vw",background:"#fff",display:"flex",flexDirection:"column",height:"100%",boxShadow:"-8px 0 40px rgba(0,0,0,.12)"}}>
        <div style={{padding:"24px 28px",borderBottom:"1px solid #f1f5f9",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <h2 style={{margin:0,fontSize:20,fontWeight:800}}>Cart ({cart.length})</h2>
          <button onClick={onClose} style={{background:"#f1f5f9",border:"none",borderRadius:"50%",width:36,height:36,cursor:"pointer",fontSize:18}}>×</button>
        </div>
        <div style={{flex:1,overflow:"auto",padding:"16px 28px"}}>
          {cart.length===0?<div style={{textAlign:"center",paddingTop:80,color:"#94a3b8"}}><div style={{fontSize:64,marginBottom:16}}>🛒</div><p style={{fontWeight:600,fontSize:16}}>Your cart is empty</p></div>
          :cart.map(item=>(
            <div key={item.id} style={{display:"flex",gap:14,padding:"16px 0",borderBottom:"1px solid #f8fafc"}}>
              <img src={item.image} alt={item.name} style={{width:72,height:72,borderRadius:10,objectFit:"cover"}}/>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,fontSize:14,marginBottom:4,lineHeight:1.3}}>{item.name}</div>
                <div style={{color:"#64748b",fontSize:12,marginBottom:8}}>{item.brand}</div>
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                  <div style={{display:"flex",alignItems:"center",border:"1px solid #e2e8f0",borderRadius:8,overflow:"hidden"}}>
                    <button onClick={()=>onUpdateQty(item.id,item.qty-1)} style={{width:30,height:30,border:"none",background:"#f8fafc",cursor:"pointer",fontWeight:700}}>−</button>
                    <span style={{width:32,textAlign:"center",fontSize:13,fontWeight:700}}>{item.qty}</span>
                    <button onClick={()=>onUpdateQty(item.id,item.qty+1)} style={{width:30,height:30,border:"none",background:"#f8fafc",cursor:"pointer",fontWeight:700}}>+</button>
                  </div>
                  <span style={{fontWeight:800,fontSize:15}}>{fmt(item.price*item.qty)}</span>
                  <button onClick={()=>onRemove(item.id)} style={{background:"none",border:"none",color:"#ef4444",cursor:"pointer",fontSize:18,padding:4}}>🗑</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        {cart.length>0&&(
          <div style={{padding:"20px 28px",borderTop:"1px solid #f1f5f9"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}><span style={{color:"#64748b"}}>Subtotal</span><span style={{fontWeight:700}}>{fmt(total)}</span></div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}><span style={{color:"#64748b"}}>Shipping</span><span style={{color:"#10b981",fontWeight:600}}>{total>499?"FREE":fmt(99)}</span></div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:20,paddingTop:12,borderTop:"2px solid #0f172a"}}>
              <span style={{fontWeight:800,fontSize:16}}>Total</span>
              <span style={{fontWeight:900,fontSize:18}}>{fmt(total>499?total:total+99)}</span>
            </div>
            <button onClick={onCheckout} style={{width:"100%",padding:"14px 0",background:"#0f172a",color:"#fff",border:"none",borderRadius:12,fontWeight:800,fontSize:16,cursor:"pointer"}}>Proceed to Checkout →</button>
          </div>
        )}
      </div>
    </div>
  );
};

const CheckoutModal = ({cart,onClose,onPlaceOrder}) => {
  const [step,setStep]=useState(1);
  const [form,setForm]=useState({name:"",email:"",phone:"",address:"",city:"",pincode:"",payment:"card"});
  const [placed,setPlaced]=useState(false);
  const [processing,setProcessing]=useState(false);
  const subtotal=cart.reduce((s,i)=>s+i.price*i.qty,0);
  const total=subtotal+(subtotal>499?0:99);
  const orderId="ORD-"+Math.random().toString(36).slice(2,10).toUpperCase();
  const inp=(f)=>({value:form[f],onChange:e=>setForm(x=>({...x,[f]:e.target.value})),style:{width:"100%",padding:"10px 14px",border:"1.5px solid #e2e8f0",borderRadius:8,fontSize:14,boxSizing:"border-box",outline:"none",fontFamily:"inherit"}});

  const handlePlace=()=>{
    setStep(3);
    setProcessing(true);
    setTimeout(()=>{setProcessing(false);setPlaced(true);},2000);
  };

  if(placed) return(
    <div style={{position:"fixed",inset:0,zIndex:1100,background:"rgba(0,0,0,.5)",display:"flex",alignItems:"center",justifyContent:"center"}}>
      <div style={{background:"#fff",borderRadius:24,padding:"60px 48px",textAlign:"center",maxWidth:460,width:"90%"}}>
        <div style={{fontSize:72,marginBottom:16}}>🎉</div>
        <h2 style={{fontSize:26,fontWeight:900,color:"#0f172a",margin:"0 0 8px"}}>Order Placed!</h2>
        <p style={{color:"#64748b",marginBottom:8}}>Thank you{form.name?`, ${form.name}`:""}!</p>
        <div style={{background:"#f8fafc",borderRadius:12,padding:"16px 20px",marginBottom:24}}>
          <div style={{fontWeight:700,color:"#0f172a",fontSize:15}}>Order #{orderId}</div>
          <div style={{color:"#64748b",fontSize:13,marginTop:4}}>Total: {fmt(total)}</div>
          <div style={{color:"#10b981",fontSize:13,marginTop:4}}>Estimated delivery: 3–5 business days</div>
        </div>
        <div style={{background:"#f1f5f9",borderRadius:10,padding:12,textAlign:"left",fontSize:11,fontFamily:"monospace",color:"#475569",marginBottom:20}}>
          POST /api/orders → order-service:8083<br/>
          POST /api/payments → payment-service:8084<br/>
          DELETE /api/cart → cart-service:8082 ✓
        </div>
        <button onClick={()=>{onPlaceOrder();onClose();}} style={{padding:"12px 36px",background:"#0f172a",color:"#fff",border:"none",borderRadius:12,fontWeight:700,fontSize:15,cursor:"pointer"}}>Continue Shopping</button>
      </div>
    </div>
  );

  return(
    <div style={{position:"fixed",inset:0,zIndex:1100,background:"rgba(0,0,0,.5)",display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
      <div style={{background:"#fff",borderRadius:20,width:"100%",maxWidth:600,maxHeight:"92vh",overflow:"auto"}}>
        <div style={{padding:"24px 32px",borderBottom:"1px solid #f1f5f9",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <h2 style={{margin:0,fontWeight:800,fontSize:20}}>Checkout</h2>
          <div style={{display:"flex",gap:8}}>
            {[1,2,3].map(s=><div key={s} style={{width:32,height:32,borderRadius:"50%",background:step>=s?"#0f172a":"#e2e8f0",color:step>=s?"#fff":"#94a3b8",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:700}}>{s}</div>)}
          </div>
          <button onClick={onClose} style={{background:"#f1f5f9",border:"none",borderRadius:"50%",width:36,height:36,cursor:"pointer",fontSize:18}}>×</button>
        </div>
        <div style={{padding:"28px 32px"}}>
          {step===1&&(
            <div style={{display:"flex",flexDirection:"column",gap:14}}>
              <h3 style={{margin:"0 0 8px",fontWeight:800}}>Shipping Details</h3>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                <div><label style={{fontSize:12,fontWeight:600,color:"#64748b",display:"block",marginBottom:4}}>Full Name</label><input {...inp("name")} placeholder="John Doe"/></div>
                <div><label style={{fontSize:12,fontWeight:600,color:"#64748b",display:"block",marginBottom:4}}>Email</label><input {...inp("email")} placeholder="john@email.com"/></div>
                <div><label style={{fontSize:12,fontWeight:600,color:"#64748b",display:"block",marginBottom:4}}>Phone</label><input {...inp("phone")} placeholder="+91 98765 43210"/></div>
                <div><label style={{fontSize:12,fontWeight:600,color:"#64748b",display:"block",marginBottom:4}}>Pincode</label><input {...inp("pincode")} placeholder="560001"/></div>
              </div>
              <div><label style={{fontSize:12,fontWeight:600,color:"#64748b",display:"block",marginBottom:4}}>Address</label><input {...inp("address")} placeholder="House/Flat, Street, Area"/></div>
              <div><label style={{fontSize:12,fontWeight:600,color:"#64748b",display:"block",marginBottom:4}}>City</label><input {...inp("city")} placeholder="Bengaluru"/></div>
              <button onClick={()=>setStep(2)} style={{marginTop:8,padding:"12px 0",background:"#0f172a",color:"#fff",border:"none",borderRadius:10,fontWeight:700,fontSize:15,cursor:"pointer"}}>Continue to Review →</button>
            </div>
          )}
          {step===2&&(
            <div>
              <h3 style={{margin:"0 0 16px",fontWeight:800}}>Order Review</h3>
              <div style={{maxHeight:200,overflow:"auto",marginBottom:16}}>
                {cart.map(item=>(
                  <div key={item.id} style={{display:"flex",gap:12,padding:"10px 0",borderBottom:"1px solid #f8fafc",alignItems:"center"}}>
                    <img src={item.image} alt={item.name} style={{width:52,height:52,borderRadius:8,objectFit:"cover"}}/>
                    <div style={{flex:1}}><div style={{fontWeight:700,fontSize:13}}>{item.name}</div><div style={{color:"#94a3b8",fontSize:12}}>Qty: {item.qty}</div></div>
                    <span style={{fontWeight:800}}>{fmt(item.price*item.qty)}</span>
                  </div>
                ))}
              </div>
              <div style={{background:"#f8fafc",borderRadius:12,padding:16,marginBottom:16}}>
                <div style={{fontSize:12,color:"#64748b",marginBottom:8,fontWeight:600}}>SHIPPING TO</div>
                <div style={{fontWeight:600,fontSize:14}}>{form.name||"—"}</div>
                <div style={{color:"#64748b",fontSize:13}}>{form.address}, {form.city} {form.pincode}</div>
              </div>
              <div style={{marginBottom:16}}>
                <div style={{fontSize:12,fontWeight:700,color:"#64748b",marginBottom:10}}>PAYMENT METHOD</div>
                {[["card","💳 Credit / Debit Card"],["upi","📱 UPI / GPay / PhonePe"],["cod","🚚 Cash on Delivery"]].map(([v,l])=>(
                  <label key={v} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",border:`2px solid ${form.payment===v?"#0f172a":"#e2e8f0"}`,borderRadius:10,marginBottom:8,cursor:"pointer"}}>
                    <input type="radio" value={v} checked={form.payment===v} onChange={()=>setForm(f=>({...f,payment:v}))} style={{margin:0}}/><span style={{fontWeight:600,fontSize:14}}>{l}</span>
                  </label>
                ))}
              </div>
              <div style={{padding:"12px 0",borderTop:"2px solid #0f172a",display:"flex",justifyContent:"space-between",marginBottom:16}}>
                <span style={{fontWeight:800,fontSize:16}}>Total</span>
                <span style={{fontWeight:900,fontSize:18}}>{fmt(total)}</span>
              </div>
              <div style={{display:"flex",gap:12}}>
                <button onClick={()=>setStep(1)} style={{flex:1,padding:"12px 0",background:"#f1f5f9",color:"#0f172a",border:"none",borderRadius:10,fontWeight:700,fontSize:14,cursor:"pointer"}}>← Back</button>
                <button onClick={handlePlace} style={{flex:2,padding:"12px 0",background:"#0f172a",color:"#fff",border:"none",borderRadius:10,fontWeight:700,fontSize:15,cursor:"pointer"}}>Place Order →</button>
              </div>
            </div>
          )}
          {step===3&&(
            <div style={{textAlign:"center",padding:"48px 0"}}>
              <div style={{fontSize:52,marginBottom:20}}>⚙️</div>
              <h3 style={{fontWeight:800,marginBottom:8}}>Processing your order…</h3>
              <p style={{color:"#64748b",fontSize:14,marginBottom:20}}>Routing through API Gateway → Microservices</p>
              <div style={{background:"#f8fafc",borderRadius:10,padding:16,textAlign:"left",fontSize:12,fontFamily:"monospace",color:"#475569",lineHeight:1.8}}>
                POST /api/orders → order-service:8083<br/>
                {"  "}→ CartClient.getCart() [Feign: cart-service]<br/>
                POST /api/payments → payment-service:8084<br/>
                {"  "}→ PaymentStatus: SUCCESS ✓<br/>
                DELETE /api/cart → cart-service:8082 ✓
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default function SpringCart() {
  const [category,setCategory]=useState("All");
  const [search,setSearch]=useState("");
  const [sort,setSort]=useState("default");
  const [cart,setCart]=useState([]);
  const [cartOpen,setCartOpen]=useState(false);
  const [checkoutOpen,setCheckoutOpen]=useState(false);
  const [viewProduct,setViewProduct]=useState(null);
  const [toast,setToast]=useState(null);
  const [page,setPage]=useState(1);
  const PER_PAGE=8;

  const showToast=useCallback(msg=>{setToast(null);setTimeout(()=>setToast(msg),10);},[]);
  const addToCart=useCallback((product,qty=1)=>{
    setCart(c=>{const ex=c.find(i=>i.id===product.id);if(ex)return c.map(i=>i.id===product.id?{...i,qty:i.qty+qty}:i);return[...c,{...product,qty}];});
    showToast(`${product.name} added to cart`);
  },[showToast]);
  const removeFromCart=useCallback(id=>setCart(c=>c.filter(i=>i.id!==id)),[]);
  const updateQty=useCallback((id,qty)=>{if(qty<=0)removeFromCart(id);else setCart(c=>c.map(i=>i.id===id?{...i,qty}:i));},[removeFromCart]);

  const filtered=PRODUCTS
    .filter(p=>category==="All"||p.category===category)
    .filter(p=>!search||p.name.toLowerCase().includes(search.toLowerCase())||p.brand.toLowerCase().includes(search.toLowerCase()))
    .sort((a,b)=>sort==="price-asc"?a.price-b.price:sort==="price-desc"?b.price-a.price:sort==="rating"?b.rating-a.rating:0);

  const paginated=filtered.slice((page-1)*PER_PAGE,page*PER_PAGE);
  const totalPages=Math.ceil(filtered.length/PER_PAGE);
  const cartCount=cart.reduce((s,i)=>s+i.qty,0);

  return (
    <div style={{minHeight:"100vh",background:"#f8fafc",fontFamily:"'Segoe UI',system-ui,sans-serif"}}>
      <style>{`@keyframes slideUp{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}} *{box-sizing:border-box} ::-webkit-scrollbar{width:6px} ::-webkit-scrollbar-track{background:#f1f5f9} ::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:3px}`}</style>

      {/* NAV */}
      <header style={{position:"sticky",top:0,zIndex:500,background:"#0f172a",color:"#fff",padding:"0 24px",boxShadow:"0 2px 20px rgba(0,0,0,.2)"}}>
        <div style={{maxWidth:1280,margin:"0 auto",display:"flex",alignItems:"center",height:64,gap:16}}>
          <div style={{fontWeight:900,fontSize:20,flexShrink:0}}>🛒 <span style={{color:"#34d399"}}>Spring</span>Cart</div>
          <div style={{flex:1,position:"relative",maxWidth:440}}>
            <span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",color:"#94a3b8"}}>🔍</span>
            <input value={search} onChange={e=>{setSearch(e.target.value);setPage(1);}} placeholder="Search products, brands…"
              style={{width:"100%",padding:"9px 14px 9px 40px",background:"#1e293b",border:"1.5px solid #334155",borderRadius:24,color:"#fff",fontSize:14,outline:"none"}}/>
          </div>
          <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:12}}>
            <div style={{fontSize:11,color:"#94a3b8",textAlign:"right",lineHeight:1.6}}>
              <span style={{color:"#34d399",fontWeight:700,display:"block"}}>Eureka :8761 ✓</span>
              <span>Gateway :8080</span>
            </div>
            <button onClick={()=>setCartOpen(true)} style={{position:"relative",background:"#1e293b",border:"1.5px solid #334155",borderRadius:12,padding:"9px 16px",color:"#fff",cursor:"pointer",display:"flex",alignItems:"center",gap:8,fontSize:14,fontWeight:600}}>
              🛒 Cart
              {cartCount>0&&<span style={{position:"absolute",top:-8,right:-8,background:"#ef4444",color:"#fff",borderRadius:"50%",width:22,height:22,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800}}>{cartCount}</span>}
            </button>
          </div>
        </div>
      </header>

      {/* HERO */}
      <div style={{background:"linear-gradient(135deg,#0f172a 0%,#1e3a5f 50%,#0f172a 100%)",padding:"48px 24px",textAlign:"center",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",inset:0,opacity:.06,backgroundImage:"radial-gradient(circle at 20% 50%,#34d399 0%,transparent 50%),radial-gradient(circle at 80% 50%,#3b82f6 0%,transparent 50%)"}}/>
        <h1 style={{margin:"0 0 12px",fontSize:"clamp(28px,5vw,42px)",fontWeight:900,color:"#fff",letterSpacing:"-1px"}}>SpringCart <span style={{color:"#34d399"}}>Microservices</span></h1>
        <p style={{margin:"0 auto 20px",color:"#94a3b8",fontSize:15,maxWidth:560}}>Full-stack e-commerce · Spring Boot + Spring Cloud + Eureka + API Gateway + JWT + Docker + K8s</p>
        <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap"}}>
          {["Spring Boot 3.2","Spring Cloud","Netflix Eureka","API Gateway","OpenFeign","JWT Auth","Docker","Kubernetes","MySQL"].map(t=>(
            <span key={t} style={{background:"rgba(255,255,255,.1)",border:"1px solid rgba(255,255,255,.15)",color:"#e2e8f0",padding:"4px 12px",borderRadius:20,fontSize:11,fontWeight:600}}>{t}</span>
          ))}
        </div>
      </div>

      {/* ARCH BAR */}
      <div style={{background:"#1e293b",padding:"10px 24px",overflowX:"auto"}}>
        <div style={{display:"flex",alignItems:"center",gap:6,justifyContent:"center",minWidth:"fit-content"}}>
          {[{l:"React UI",c:"#3b82f6"},{l:"→",c:"#475569"},{l:"API Gateway :8080",c:"#8b5cf6"},{l:"→",c:"#475569"},
            {l:"Product :8081",c:"#10b981"},{l:"Cart :8082",c:"#f59e0b"},{l:"Order :8083",c:"#ef4444"},{l:"Payment :8084",c:"#06b6d4"},
            {l:"→",c:"#475569"},{l:"MySQL :3306",c:"#f97316"},{l:"|",c:"#334155"},{l:"Eureka :8761",c:"#a855f7"}
          ].map((s,i)=>s.l==="→"||s.l==="|"?<span key={i} style={{color:s.c,fontSize:s.l==="→"?16:18,margin:"0 2px"}}>{s.l}</span>:(
            <span key={i} style={{background:"rgba(255,255,255,.05)",border:`1px solid ${s.c}40`,borderRadius:8,padding:"4px 10px",fontSize:11,color:s.c,fontWeight:700,whiteSpace:"nowrap"}}>{s.l}</span>
          ))}
        </div>
      </div>

      <div style={{maxWidth:1280,margin:"0 auto",padding:"24px 24px"}}>
        {/* FILTERS */}
        <div style={{display:"flex",gap:10,marginBottom:20,alignItems:"center",flexWrap:"wrap"}}>
          <div style={{display:"flex",gap:6,flexWrap:"wrap",flex:1}}>
            {CATEGORIES.map(cat=>(
              <button key={cat} onClick={()=>{setCategory(cat);setPage(1);}} style={{padding:"7px 16px",borderRadius:24,background:category===cat?"#0f172a":"#fff",color:category===cat?"#fff":"#64748b",border:category===cat?"none":"1.5px solid #e2e8f0",fontWeight:600,fontSize:13,cursor:"pointer",transition:"all .2s"}}>{cat}</button>
            ))}
          </div>
          <select value={sort} onChange={e=>{setSort(e.target.value);setPage(1);}} style={{padding:"8px 14px",borderRadius:10,border:"1.5px solid #e2e8f0",background:"#fff",fontSize:13,fontWeight:600,color:"#475569",cursor:"pointer",outline:"none"}}>
            <option value="default">Sort: Default</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
        </div>

        <div style={{color:"#64748b",fontSize:13,marginBottom:18,fontWeight:500}}>
          Showing {paginated.length} of {filtered.length} products
          {search&&<span> for "<strong>{search}</strong>"</span>}
          {category!=="All"&&<span> in <strong>{category}</strong></span>}
        </div>

        {paginated.length===0?(
          <div style={{textAlign:"center",padding:"80px 0",color:"#94a3b8"}}>
            <div style={{fontSize:56}}>🔍</div>
            <p style={{fontWeight:600,fontSize:16,marginTop:12}}>No products found</p>
          </div>
        ):(
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(230px,1fr))",gap:20}}>
            {paginated.map(p=><ProductCard key={p.id} product={p} onAddToCart={addToCart} onView={setViewProduct}/>)}
          </div>
        )}

        {totalPages>1&&(
          <div style={{display:"flex",justifyContent:"center",gap:8,marginTop:36}}>
            <button onClick={()=>setPage(p=>Math.max(1,p-1))} disabled={page===1} style={{padding:"8px 14px",borderRadius:8,border:"1.5px solid #e2e8f0",background:"#fff",cursor:page===1?"not-allowed":"pointer",color:page===1?"#cbd5e1":"#0f172a",fontWeight:700}}>← Prev</button>
            {Array.from({length:totalPages},(_,i)=>i+1).map(n=>(
              <button key={n} onClick={()=>setPage(n)} style={{width:36,height:36,borderRadius:8,border:page===n?"none":"1.5px solid #e2e8f0",background:page===n?"#0f172a":"#fff",color:page===n?"#fff":"#0f172a",fontWeight:700,cursor:"pointer"}}>{n}</button>
            ))}
            <button onClick={()=>setPage(p=>Math.min(totalPages,p+1))} disabled={page===totalPages} style={{padding:"8px 14px",borderRadius:8,border:"1.5px solid #e2e8f0",background:"#fff",cursor:page===totalPages?"not-allowed":"pointer",color:page===totalPages?"#cbd5e1":"#0f172a",fontWeight:700}}>Next →</button>
          </div>
        )}
      </div>

      <footer style={{background:"#0f172a",color:"#94a3b8",padding:"32px 24px",marginTop:40,textAlign:"center"}}>
        <div style={{fontWeight:800,fontSize:18,color:"#fff",marginBottom:8}}>🛒 SpringCart — Microservices E-Commerce</div>
        <div style={{display:"flex",gap:12,justifyContent:"center",flexWrap:"wrap",fontSize:12}}>
          {["Eureka :8761","API Gateway :8080","Product :8081","Cart :8082","Order :8083","Payment :8084"].map(s=><span key={s} style={{color:"#34d399",fontWeight:600}}>● {s}</span>)}
        </div>
      </footer>

      {cartOpen&&<CartSidebar cart={cart} onClose={()=>setCartOpen(false)} onRemove={removeFromCart} onUpdateQty={updateQty} onCheckout={()=>{setCartOpen(false);setCheckoutOpen(true);}}/>}
      {checkoutOpen&&<CheckoutModal cart={cart} onClose={()=>setCheckoutOpen(false)} onPlaceOrder={()=>setCart([])}/>}
      {viewProduct&&<ProductModal product={viewProduct} onClose={()=>setViewProduct(null)} onAddToCart={addToCart}/>}
      {toast&&<Toast key={toast} msg={toast} onClose={()=>setToast(null)}/>}
    </div>
  );
}
